package strategy.supervisor;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



public class SupervisorAssignmentFactory {

    private SupervisorAssignmentFactory() {
        // private constructor to prevent direct instantiation
    }

    public static SupervisorAssignmentStrategy createStrategy(String strategyType) {
      
    }
}
