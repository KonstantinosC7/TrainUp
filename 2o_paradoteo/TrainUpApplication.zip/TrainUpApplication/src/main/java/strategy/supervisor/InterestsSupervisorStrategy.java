package strategy.supervisor;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


import TraineeshipApplication.model.Professor;
import TraineeshipApplication.model.TraineeshipPosition;

public class InterestsSupervisorStrategy implements SupervisorAssignmentStrategy {

    private double threshold = 0.3;

    @Override
    public Professor assign(List<Professor> allProfs, TraineeshipPosition position) {
        
    }

    private double jaccardSimilarity(Set<String> setA, Set<String> setB) {
        
    }
}
