package strategy.supervisor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import TraineeshipApplication.model.Professor;
import TraineeshipApplication.model.TraineeshipPosition;

public class MinLoadSupervisorStrategy implements SupervisorAssignmentStrategy {

    @Override
    public Professor assign(List<Professor> allProfs, TraineeshipPosition position) {
          
    }
}
