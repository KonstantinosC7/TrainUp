package strategy.search;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import TraineeshipApplication.model.Student;
import TraineeshipApplication.model.TraineeshipPosition;

/**
 * A strategy that returns positions that match BOTH the interests-based approach
 * AND the location-based approach (intersection of results).
 */


public class BothStrategy implements PositionsSearchStrategy {

    private final PositionsSearchStrategy interestsStrategy;
    private final PositionsSearchStrategy locationStrategy;

    public BothStrategy(PositionsSearchStrategy interestsStrategy,
                        PositionsSearchStrategy locationStrategy) {
        this.interestsStrategy = interestsStrategy;
        this.locationStrategy = locationStrategy;
    }

    @Override
    public List<TraineeshipPosition> searchPositions(Student student, List<TraineeshipPosition> availablePositions) {
        
    }
}

