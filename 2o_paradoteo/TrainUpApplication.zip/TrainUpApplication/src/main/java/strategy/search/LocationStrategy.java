package strategy.search;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import TraineeshipApplication.model.Company;
import TraineeshipApplication.model.Student;
import TraineeshipApplication.model.TraineeshipPosition;

public class LocationStrategy implements PositionsSearchStrategy {

    @Override
    public List<TraineeshipPosition> searchPositions(Student student, List<TraineeshipPosition> availablePositions) {
        
    }

    private boolean studentHasRequiredSkills(Student s, TraineeshipPosition p) {
        
    }
}



