package strategy.search;

import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;


import TraineeshipApplication.model.Student;
import TraineeshipApplication.model.TraineeshipPosition;

public class PositionsSearchFactory {

    private PositionsSearchFactory() {
        // private constructor to prevent instantiation
    }

    public static PositionsSearchStrategy createStrategy(String strategyType) {
       
    }
}

