package strategy.search;

import java.util.*

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import TraineeshipApplication.model.Student;
import TraineeshipApplication.model.TraineeshipPosition;


public class InterestsStrategy implements PositionsSearchStrategy {

    private double threshold = 0.3; // or pass in constructor if needed

    @Override
    public List<TraineeshipPosition> searchPositions(Student student, List<TraineeshipPosition> availablePositions) {
       
    }

    private double jaccardSimilarity(Set<String> setA, Set<String> setB) {
        
    }

    private boolean studentHasRequiredSkills(Student s, TraineeshipPosition p) {
        
    }
}


