package TraineeshipApplication.model;

public enum EvaluationType {
    PROFESSOR,
    COMPANY
}
